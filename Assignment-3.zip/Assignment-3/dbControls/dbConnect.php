<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "assignment3";
    $conn = mysqli_connect($servername, $username, $password,$db);

